// frontend/script.js
let allProducts = [];

fetch("http://localhost:5000/api/products")
  .then(res => res.json())
  .then(products => {
    allProducts = products;
  });

function searchProducts() {
  const query = document.getElementById("search-bar").value.toLowerCase();
  const results = allProducts.filter(product =>
    product.name.toLowerCase().includes(query) ||
    product.ingredients.some(ing => ing.toLowerCase().includes(query))
  );
  localStorage.setItem("searchResults", JSON.stringify(results));
  window.location.href = "products.html";
}
