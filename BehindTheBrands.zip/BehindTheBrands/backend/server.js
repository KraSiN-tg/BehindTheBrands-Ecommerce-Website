const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const productRoutes = require("./routes/productRoutes");
const cartRoutes = require("./routes/cartRoutes");
const path = require("path");
const Product = require("./models/product"); // ✅ Import Product model
const User = require("./models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(bodyParser.json());

mongoose.connect("mongodb://localhost:27017/BehindTheBrands", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

app.use("/api/products", productRoutes);
app.use("/api/cart", cartRoutes);
app.use("/images", express.static(path.join(__dirname, "public", "images")));

app.get("/api/product/:id", async (req, res) => {
  try {
    const productId = req.params.id;

    // Validate if productId is a valid MongoDB ObjectId
    if (!mongoose.Types.ObjectId.isValid(productId)) {
      return res.status(400).json({ error: "Invalid product ID" });
    }

    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.json(product);
  } catch (error) {
    console.error("Error fetching product:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.post("/api/register", async (req, res) => {
  const { username, email, password } = req.body;

  try {
      // Check if user already exists
      let user = await User.findOne({ email });
      if (user) {
          return res.status(400).json({ msg: "User already exists" });
      }

      // Hash the password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);

      // Create new user
      user = new User({ username, email, password: hashedPassword });
      await user.save();

      res.status(201).json({ msg: "User registered successfully!" });
  } catch (err) {
      console.error(err);
      res.status(500).json({ msg: "Server error" });
  }
});

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;

  try {
      // Find user by email
      let user = await User.findOne({ email });
      if (!user) {
          return res.status(400).json({ msg: "Invalid Credentials" });
      }

      // Check password
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
          return res.status(400).json({ msg: "Invalid Credentials" });
      }

      // Generate JWT Token
      const token = jwt.sign({ id: user._id, username: user.username }, "your_secret_key", { expiresIn: "1h" });

      res.json({ token, username: user.username });
  } catch (err) {
      console.error(err);
      res.status(500).json({ msg: "Server error" });
  }
});


app.listen(5000, () => console.log("Server running on port 5000"));
