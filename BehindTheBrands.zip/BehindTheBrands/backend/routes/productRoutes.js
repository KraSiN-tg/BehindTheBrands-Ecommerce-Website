const express = require("express");
const router = express.Router();
const Product = require("../models/product");

// ✅ General Route (Handles Filtering)
router.get("/", async (req, res) => {
    try {
        const { ingredient } = req.query;
        let query = {};

        // ✅ If ingredient exists, filter products that have it in the array
        if (ingredient) {
            query.ingredients = { $regex: new RegExp(ingredient, "i") }; // Case-insensitive match
        }

        const products = await Product.find(query);
        res.json(products);
    } catch (error) {
        console.error("Error fetching products:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// ✅ Route to Add Products
router.post("/add", async (req, res) => {
    try {
        const newProduct = new Product(req.body);
        await newProduct.save();
        res.json({ message: "Product added successfully!" });
    } catch (error) {
        console.error("Error adding product:", error);
        res.status(500).json({ error: "Failed to add product" });
    }
});

module.exports = router;
